# -*- coding: utf-8 -*

import json
import os
import re
from Utils import *
import numpy as np
from content_split import *

output_folder = "../data-v1_0804"
mkdir(output_folder)

fltr = '[’!"#$%&\'()*+,-./:;<=>?@，。?★、…【】《》？“”‘’！[\\]^_`{|}~]+'

def mark_position(article, amls):
    content = article
    content = re.sub(fltr, ' ', content)
    position_list = []
    
    for aml in amls:
        aml = re.sub(fltr, ' ', aml)
        aml = aml.strip()
        position = [{'begin': m.start(), 'end': (m.end() - 1)} for m in re.finditer(aml, content)]
        if len(position) == 0: continue
        position_list += position

    return position_list

def mark(article, amls):
    label_positions = mark_position(article, amls)
    content = article
    label_mark = ["O"] * len(content)
    length = len(content)

    for position in label_positions:
        begin = position["begin"]
        end = position["end"]

        if begin >= length:
            break

        label_mark[begin] = "B_NAME"
        for i in range((begin + 1), (end + 1)):
            label_mark[i] = "I_NAME"

    for position in label_positions:
        begin = position["begin"]
        end = position["end"]

        if begin >= length:
            break

#         print("checking: {} {},{}".format(article[begin:end + 1], begin, end))

    return label_mark

def file_append(output_file, msg):
    with open(output_file, "a") as f:
        f.write(msg)


def file_write(output_file, msg):
    with open(output_file, "w") as f:
        f.write(msg)

def fwrite_append(output_file, text):
    with open(output_file, "a") as f:
        f.write(text)


def delete_file(file):
    try:
        os.remove(file)
    except Exception as e:
        print(e)
        
        

def ner_format(article, amls):

    labels = mark(article, amls)

    return ' '.join(labels)


def generate_ner_training_data(news_data, fraction_train, fraction_dev):
    
    print("Total articles:{}".format(len(news_data)))
    cnt = 0
    
    labeled_lines = []
    for idx, news in enumerate(news_data):
        if len(news["name"]) > 0:
            cnt = cnt + 1
            article = news["full_content"]
            article = remove_symbols(article)
            article = remove_whitespace(article)
            labeled_data = ner_format(article, news["name"])
            labeled_line = "tbrain\t{}\t{}\t{}\t{}\n".format(article, labeled_data, ','.join(news["name"]), news["news_ID"])
            labeled_lines.append(labeled_line)
            
    seed = 777
    np.random.seed(seed)
    np.random.shuffle(labeled_lines)

    total = len(labeled_lines)
    train_pos = int(total* fraction_train)
    dev_pos = int(total * fraction_dev)
    log("total:{} train_pos:{} dev_pos:{}".format(total, train_pos, dev_pos))
    
    global output_folder
    
    output_file_trian = f"{output_folder}/train.tsv"
    output_file_dev = f"{output_folder}/dev.tsv"
    output_file_test = f"{output_folder}/test.tsv"
    
    delete_file(output_file_trian)
    delete_file(output_file_dev)
    delete_file(output_file_test)
    
    dump_lines(labeled_lines[0:train_pos], output_file_trian)
    dump_lines(labeled_lines[train_pos:dev_pos], output_file_dev)
    dump_lines(labeled_lines[dev_pos:total], output_file_test)


def parse_my_names(text):
    if text == '[]' or len(text) == 0:
        return []
#     print('text:{}'.format(text))
    tokens = text[1:len(text) - 1].split(",")
    names = []
    for token in tokens:
        token = token.strip()
#         print(token)
        names.append(token[1: len(token) - 1])
    
#     print(names)
    return names
    
def parse_reviewed_names(text):
    names = text.split(" ")
    
    result = []
    for name in names:
        if len(name.strip()) > 0:
            result.append(name)
            
    return result

def load_esun_reviewed_file(file_path):
    items = []
    
    with open(file_path) as fp:
        Lines = fp.readlines()
        for idx, line in enumerate(Lines):
            tokens = line.strip().split("\t")
            my_names = parse_my_names(tokens[3])
            names = []
            if len(tokens) >= 5:
                names = parse_reviewed_names(tokens[4])
            
            items.append({
                "news_ID": f"{file_path}-idx",
                "full_content": tokens[2],
                "my_names": my_names,
                "name": names
            })            
            
    return items


def load_esun_reviewed_files():
    file_paths = ["/app/esun_log/reviewed_result_2020-07-27.tsv",
                 "/app/esun_log/reviewed_result_2020-07-28.tsv",
                 "/app/esun_log/reviewed_result_2020-07-29.tsv",
                 "/app/esun_log/reviewed_result_2020-07-30.tsv",
                 "/app/esun_log/reviewed_result_2020-08-03.tsv",
                 "/app/esun_log/reviewed_result_2020-08-04.tsv"]
    
    dataset = []
    for file_path in file_paths:
        news = load_esun_reviewed_file(file_path)
        print("{}:{}".format(file_path, len(news)))
        dataset = dataset + news
    return dataset
        
def combine_training_and_race_data_for_final():
    esun_training_data = load_json("../../data/dataset.json")
    print(len(esun_training_data))
    esun_v1_data = load_esun_reviewed_files()
    print(len(esun_v1_data))
    combined_dataset = esun_training_data + esun_v1_data
    print(len(combined_dataset))
    return combined_dataset
    
    
def main():
    news_data = combine_training_and_race_data_for_final()
    dump_json("../../data/dataset-0804.json", news_data)
    news_data = load_json("../../data/dataset-0804.json")
    generate_ner_training_data(news_data, 1.0, 0.2)

main()