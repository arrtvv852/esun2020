from flask import Flask
from flask import request
from flask import jsonify
import time
import hashlib
import numpy as np
import pandas as pd
import json

from ner.src import Utils
import answer

app = Flask(__name__)
####### PUT YOUR INFORMATION HERE #######
CAPTAIN_EMAIL = 'winnt.chen@gmail.com'  #
SALT = 'codebrain_20200717'             #
#########################################
inference_count = 0
error_count = 0
healthy_count = 0


def generate_server_uuid(input_string):
    """ Create your own server_uuid
    @param input_string (str): information to be encoded as server_uuid
    @returns server_uuid (str): your unique server_uuid
    """
    s = hashlib.sha256()
    data = (input_string+SALT).encode("utf-8")
    s.update(data)
    server_uuid = s.hexdigest()
    return server_uuid

def predict(article):
    """ Predict your model result
    @param article (str): a news article
    @returns prediction (list): a list of name
    """

    ####### PUT YOUR MODEL INFERENCING CODE HERE #######
    prediction = []
    try:
        prediction = answer.extract(article, True)
    except Exception as e:
        pass
    ####################################################
    prediction = _check_datatype_to_list(prediction)
    return prediction

def _check_datatype_to_list(prediction):
    """ Check if your prediction is in list type or not. 
        And then convert your prediction to list type or raise error.

    @param prediction (list / numpy array / pandas DataFrame): your prediction
    @returns prediction (list): your prediction in list type
    """
    if isinstance(prediction, np.ndarray):
        _check_datatype_to_list(prediction.tolist())
    elif isinstance(prediction, pd.core.frame.DataFrame):
        _check_datatype_to_list(prediction.values)
    elif isinstance(prediction, list):
        return prediction
    raise ValueError('Prediction is not in list type.')
    
@app.route('/apicheck', methods=['GET'])
def apicheck():
    global inference_count, error_count
    return f"ok - inference[{inference_count}] error_count:{error_count}"


@app.route('/healthcheck', methods=['POST'])
def healthcheck():
    """ API for health check """
    data = request.get_json(force=True)  
    t = int(time.time())
    ts = str(t)
    server_uuid = generate_server_uuid(CAPTAIN_EMAIL+ts)
    server_timestamp = t
    global healthy_count
    healthy_count = healthy_count + 1
    req_ip = request.remote_addr
    res_data = {'esun_uuid': data['esun_uuid'], 'server_uuid': server_uuid, 'captain_email': CAPTAIN_EMAIL, 'server_timestamp': server_timestamp}
    res_text = json.dumps(res_data)
    Utils.log(f"[API][healthcheck][{healthy_count}] {res_text}")
    return jsonify(res_data)

@app.route('/inference', methods=['POST'])
def inference():
    """ API that return your model predictions when E.SUN calls this API """
    data = request.get_json(force=True)  
    esun_timestamp = data['esun_timestamp'] #自行取用

    t = int(time.time())
    ts = str(int(t))
    server_uuid = generate_server_uuid(CAPTAIN_EMAIL+ts)

    global error_count
    try:
        answer = predict(data['news'])
        global inference_count
        inference_count = inference_count + 1
        Utils.log(f"[API][inference][{inference_count}] article: {data['news']}")
        Utils.log(f"[API][inference][{inference_count}] answer: {answer}")
    except:
        error_count = error_count + 1
        pass
#         raise ValueError('Model error.')        
    server_timestamp = t

    return jsonify({'esun_timestamp': data['esun_timestamp'], 'server_uuid': server_uuid, 'answer': answer, 'server_timestamp': server_timestamp, 'esun_uuid': data['esun_uuid']})

if __name__ == "__main__":    
    app.run(host='0.0.0.0', port=8001, debug=True)